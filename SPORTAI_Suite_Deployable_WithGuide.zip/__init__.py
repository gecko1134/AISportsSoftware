touch sportai_suite/__init__.py

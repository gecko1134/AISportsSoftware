"""
Launcher for SPORTAI Suite
"""
import os

def main():
    print("✅ Launching SPORTAI Suite...")
    os.system("streamlit run main_app.py")

if __name__ == "__main__":
    main()

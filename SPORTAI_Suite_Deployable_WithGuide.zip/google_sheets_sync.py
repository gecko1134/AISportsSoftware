import streamlit as st
def run():
    st.title("📄 Google Sheets Sync")
    st.info("Logs events, revenue, and membership activity to shared spreadsheet.")
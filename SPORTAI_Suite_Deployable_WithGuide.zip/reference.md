# API Reference

::: ai_scheduler_tool